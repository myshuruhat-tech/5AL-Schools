package so.waafi.marks

/**
 * إعدادات التطبيق - هذا الملف الوحيد اللي تحتاج تعدله لو تغيّر الموقع.
 *
 * الحقول الثلاثة (USER_SELECTOR / PASS_SELECTOR / BUTTON_SELECTOR) فاضية = التطبيق يكتشفها تلقائياً.
 * لو الاكتشاف التلقائي ما اشتغل، حط CSS selector للحقل، مثال: "#txtUserName" أو "input[name='ctl00$user']"
 */
object Config {
    const val DOMAIN = "maanshiil.so"
    const val LOGIN_URL = "https://waafi.maanshiil.so/Default.aspx"
    const val MARKS_URL = "https://waafi.maanshiil.so/Admission/Profile/Marksheet.aspx"

    // مسارات تعتبر صفحة تسجيل دخول (بحروف صغيرة)
    val LOGIN_PATHS = listOf("", "/", "/default.aspx", "/login.aspx")

    const val USER_SELECTOR = ""
    const val PASS_SELECTOR = ""
    const val BUTTON_SELECTOR = ""
}
