package so.waafi.marks

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.http.SslError
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar

    private var fillCount = 0
    private var wentToMarks = false
    private var dialogShowing = false
    private var showingError = false

    // ---------- تخزين مشفر لبيانات الدخول ----------

    private fun securePrefs() = runCatching {
        val key = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            this,
            "secure_login",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrNull()

    private fun loadCreds(): Pair<String, String>? {
        val p = securePrefs() ?: return null
        val u = p.getString("u", null)
        val pw = p.getString("p", null)
        return if (!u.isNullOrEmpty() && !pw.isNullOrEmpty()) Pair(u, pw) else null
    }

    private fun saveCreds(u: String, p: String) {
        securePrefs()?.edit()?.putString("u", u)?.putString("p", p)?.apply()
    }

    private fun clearCreds() {
        securePrefs()?.edit()?.clear()?.apply()
    }

    // ---------- الواجهة ----------

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(
            progress,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (4 * resources.displayMetrics.density).toInt())
        )
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: ""
                if (scheme != "http" && scheme != "https") return true
                val host = uri.host ?: ""
                if (host == Config.DOMAIN || host.endsWith("." + Config.DOMAIN)) return false
                openExternal(uri)
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showError("تعذر فتح الصفحة: " + error.description)
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    showError("الموقع رجّع خطأ رقم " + errorResponse.statusCode)
                }
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                val host = Uri.parse(error.url).host ?: ""
                val ours = host == Config.HOST
                if (ours && error.primaryError == SslError.SSL_UNTRUSTED) {
                    handler.proceed()
                    return
                }
                handler.cancel()
                // الأخطاء القادمة من مواقع جانبية (ويدجت، يوتيوب، إلخ) نتجاهلها
                // بدون ما نغطي الصفحة، ونعرض الخطأ فقط لو المشكلة في موقع المدرسة نفسه
                if (ours) {
                    showError("مشكلة في شهادة الأمان (SSL): " + sslReason(error.primaryError))
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
                if (url != null && url.startsWith("http")) showingError = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.GONE
                handlePage(url ?: "")
            }
        }

        web.setDownloadListener { url, _, _, _, _ -> openExternal(Uri.parse(url)) }

        web.loadUrl(Config.LOGIN_URL)
    }

    private fun openExternal(uri: Uri) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }

    // ---------- منطق الدخول التلقائي ----------

    private fun sslReason(code: Int): String = when (code) {
        SslError.SSL_UNTRUSTED -> "الشهادة غير موثوقة"
        SslError.SSL_EXPIRED -> "الشهادة منتهية، أو تاريخ الجوال غير صحيح"
        SslError.SSL_IDMISMATCH -> "اسم الشهادة لا يطابق الموقع"
        SslError.SSL_NOTYETVALID -> "الشهادة لم تبدأ بعد، تأكد من تاريخ ووقت الجوال"
        SslError.SSL_DATE_INVALID -> "تاريخ الشهادة غير صحيح، تأكد من تاريخ ووقت الجوال"
        else -> "خطأ غير معروف ($code)"
    }

    private fun showError(msg: String) {
        showingError = true
        val html = "<html><body dir='rtl' style='font-family:sans-serif;padding:24px;text-align:center'>" +
            "<h3>" + msg + "</h3><p>تأكد من الإنترنت ثم اختر تحديث من القائمة (⋮)</p></body></html>"
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    private fun handlePage(url: String) {
        if (!url.startsWith("http")) return
        val path = (Uri.parse(url).path ?: "").lowercase()
        val isLogin = Config.LOGIN_PATHS.contains(path)

        if (isLogin) {
            wentToMarks = false
            val creds = loadCreds()
            when {
                creds == null -> askCreds(false)
                fillCount < 2 -> {
                    fillCount++
                    fill(creds)
                }
                else -> {
                    // رجعنا لصفحة الدخول بعد المحاولة = غالباً البيانات غلط
                    fillCount = 0
                    clearCreds()
                    askCreds(true)
                }
            }
        } else {
            fillCount = 0
            if (!wentToMarks && !path.contains("marksheet")) {
                wentToMarks = true
                web.loadUrl(Config.MARKS_URL)
            }
        }
    }

    private fun askCreds(wrong: Boolean) {
        if (dialogShowing) return
        dialogShowing = true

        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val user = EditText(this).apply {
            hint = "اسم المستخدم"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val pass = EditText(this).apply {
            hint = "كلمة المرور"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        box.addView(user)
        box.addView(pass)

        AlertDialog.Builder(this)
            .setTitle(if (wrong) "البيانات غير صحيحة، أعد الإدخال" else "تسجيل الدخول")
            .setView(box)
            .setPositiveButton("حفظ ودخول") { _, _ ->
                dialogShowing = false
                val u = user.text.toString().trim()
                val p = pass.text.toString()
                if (u.isNotEmpty() && p.isNotEmpty()) {
                    saveCreds(u, p)
                    fillCount = 1
                    fill(Pair(u, p))
                }
            }
            .setNegativeButton("إلغاء") { _, _ -> dialogShowing = false }
            .setOnCancelListener { dialogShowing = false }
            .show()
    }

    private fun fill(c: Pair<String, String>) {
        val js = """
            (function(){
              var U = ${JSONObject.quote(c.first)};
              var P = ${JSONObject.quote(c.second)};
              var US = ${JSONObject.quote(Config.USER_SELECTOR)};
              var PS = ${JSONObject.quote(Config.PASS_SELECTOR)};
              var BS = ${JSONObject.quote(Config.BUTTON_SELECTOR)};
              var MS = ${JSONObject.quote(Config.MOBILE_SELECTOR)};
              var p = PS ? document.querySelector(PS) : document.querySelector('input[type=password]');
              if (!p) return 'no-password-field';
              var u = null;
              if (US) {
                u = document.querySelector(US);
              } else {
                var all = Array.prototype.slice.call(document.querySelectorAll('input'));
                for (var i = all.indexOf(p) - 1; i >= 0; i--) {
                  var t = (all[i].getAttribute('type') || 'text').toLowerCase();
                  if (t === 'text' || t === 'email' || t === 'tel' || t === 'number') { u = all[i]; break; }
                }
              }
              if (!u) return 'no-user-field';
              function setVal(el, v) {
                var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
                d.set.call(el, v);
                el.dispatchEvent(new Event('input', {bubbles: true}));
                el.dispatchEvent(new Event('change', {bubbles: true}));
              }
              var scope = p.form || document;
              var b = BS ? document.querySelector(BS)
                : (scope.querySelector('input[type=submit], button[type=submit]')
                   || scope.querySelector('input[type=button], button, a.btn, a[id*=ogin]'));
              var m = MS ? document.querySelector(MS) : null;
              if (!m) {
                var found = Array.prototype.slice.call(document.querySelectorAll(
                  '.fa-mobile, .fa-tablet, .fa-mobile-phone, .fa-mobile-alt, .fa-mobile-screen, [class*=mobile], [class*=tablet], [onclick*=obile], [title*=obile], img[src*=obile]'
                )).filter(function(e){ return e.offsetWidth > 0 && e.offsetWidth <= 60 && e.offsetHeight <= 60; });
                if (found.length) m = found[0];
              }
              if (!m && b) {
                var cand = Array.prototype.slice.call(document.querySelectorAll('i, img, svg')).filter(function(e){
                  return (b.compareDocumentPosition(e) & 4) && e.offsetWidth > 0 && e.offsetWidth <= 48 && !(e.textContent || '').trim();
                });
                if (cand.length >= 2) m = cand[1];
              }
              if (m) { var mt = m.closest('a, button, [onclick]') || m; mt.click(); }
              setTimeout(function(){
                setVal(u, U);
                setVal(p, P);
                if (b) { b.click(); } else if (p.form) { p.form.submit(); }
              }, 400);
              return m ? 'mode-clicked' : 'no-mode-icon';
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    // ---------- القائمة ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "الدرجات").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        menu.add(0, 2, 1, "تحديث").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        menu.add(0, 3, 2, "نسيان بيانات الدخول")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> {
                wentToMarks = true
                web.loadUrl(Config.MARKS_URL)
            }
            2 -> {
                if (showingError) {
                    // reload() كان يعيد صفحة الخطأ نفسها، نرجع نفتح الموقع من البداية
                    fillCount = 0
                    wentToMarks = false
                    web.loadUrl(Config.LOGIN_URL)
                } else {
                    web.reload()
                }
            }
            3 -> {
                clearCreds()
                fillCount = 0
                wentToMarks = false
                CookieManager.getInstance().removeAllCookies(null)
                web.loadUrl(Config.LOGIN_URL)
            }
        }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
