package so.waafi.marks

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar

    private var fillAttempted = false
    private var wentToMarks = false
    private var dialogShowing = false

    // ---------- تخزين مشفر لبيانات الدخول ----------

    private fun securePrefs() = runCatching {
        val key = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            this,
            "secure_login",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrNull()

    private fun loadCreds(): Pair<String, String>? {
        val p = securePrefs() ?: return null
        val u = p.getString("u", null)
        val pw = p.getString("p", null)
        return if (!u.isNullOrEmpty() && !pw.isNullOrEmpty()) Pair(u, pw) else null
    }

    private fun saveCreds(u: String, p: String) {
        securePrefs()?.edit()?.putString("u", u)?.putString("p", p)?.apply()
    }

    private fun clearCreds() {
        securePrefs()?.edit()?.clear()?.apply()
    }

    // ---------- الواجهة ----------

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(
            progress,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (4 * resources.displayMetrics.density).toInt())
        )
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().setAcceptCookie(true)

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: ""
                if (scheme != "http" && scheme != "https") return true
                val host = uri.host ?: ""
                if (host == Config.DOMAIN || host.endsWith("." + Config.DOMAIN)) return false
                openExternal(uri)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                progress.visibility = View.GONE
                handlePage(url ?: "")
            }
        }

        web.setDownloadListener { url, _, _, _, _ -> openExternal(Uri.parse(url)) }

        web.loadUrl(Config.LOGIN_URL)
    }

    private fun openExternal(uri: Uri) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }

    // ---------- منطق الدخول التلقائي ----------

    private fun handlePage(url: String) {
        val path = (Uri.parse(url).path ?: "").lowercase()
        val isLogin = Config.LOGIN_PATHS.contains(path)

        if (isLogin) {
            wentToMarks = false
            val creds = loadCreds()
            when {
                creds == null -> askCreds(false)
                !fillAttempted -> {
                    fillAttempted = true
                    fill(creds)
                }
                else -> {
                    // رجعنا لصفحة الدخول بعد المحاولة = غالباً البيانات غلط
                    fillAttempted = false
                    clearCreds()
                    askCreds(true)
                }
            }
        } else {
            fillAttempted = false
            if (!wentToMarks && !path.contains("marksheet")) {
                wentToMarks = true
                web.loadUrl(Config.MARKS_URL)
            }
        }
    }

    private fun askCreds(wrong: Boolean) {
        if (dialogShowing) return
        dialogShowing = true

        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val user = EditText(this).apply {
            hint = "اسم المستخدم"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val pass = EditText(this).apply {
            hint = "كلمة المرور"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        box.addView(user)
        box.addView(pass)

        AlertDialog.Builder(this)
            .setTitle(if (wrong) "البيانات غير صحيحة، أعد الإدخال" else "تسجيل الدخول")
            .setView(box)
            .setPositiveButton("حفظ ودخول") { _, _ ->
                dialogShowing = false
                val u = user.text.toString().trim()
                val p = pass.text.toString()
                if (u.isNotEmpty() && p.isNotEmpty()) {
                    saveCreds(u, p)
                    fillAttempted = true
                    fill(Pair(u, p))
                }
            }
            .setNegativeButton("إلغاء") { _, _ -> dialogShowing = false }
            .setOnCancelListener { dialogShowing = false }
            .show()
    }

    private fun fill(c: Pair<String, String>) {
        val js = """
            (function(){
              var U = ${JSONObject.quote(c.first)};
              var P = ${JSONObject.quote(c.second)};
              var US = ${JSONObject.quote(Config.USER_SELECTOR)};
              var PS = ${JSONObject.quote(Config.PASS_SELECTOR)};
              var BS = ${JSONObject.quote(Config.BUTTON_SELECTOR)};
              var p = PS ? document.querySelector(PS) : document.querySelector('input[type=password]');
              if (!p) return 'no-password-field';
              var u = null;
              if (US) {
                u = document.querySelector(US);
              } else {
                var all = Array.prototype.slice.call(document.querySelectorAll('input'));
                for (var i = all.indexOf(p) - 1; i >= 0; i--) {
                  var t = (all[i].getAttribute('type') || 'text').toLowerCase();
                  if (t === 'text' || t === 'email' || t === 'tel' || t === 'number') { u = all[i]; break; }
                }
              }
              if (!u) return 'no-user-field';
              function setVal(el, v) {
                var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
                d.set.call(el, v);
                el.dispatchEvent(new Event('input', {bubbles: true}));
                el.dispatchEvent(new Event('change', {bubbles: true}));
              }
              setVal(u, U);
              setVal(p, P);
              var scope = p.form || document;
              var b = BS ? document.querySelector(BS)
                : (scope.querySelector('input[type=submit], button[type=submit]')
                   || scope.querySelector('input[type=button], button, a.btn, a[id*=ogin]'));
              if (b) { setTimeout(function(){ b.click(); }, 300); return 'clicked'; }
              if (p.form) { p.form.submit(); return 'submitted'; }
              return 'no-button';
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    // ---------- القائمة ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "الدرجات").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        menu.add(0, 2, 1, "تحديث").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        menu.add(0, 3, 2, "نسيان بيانات الدخول")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> {
                wentToMarks = true
                web.loadUrl(Config.MARKS_URL)
            }
            2 -> web.reload()
            3 -> {
                clearCreds()
                fillAttempted = false
                wentToMarks = false
                CookieManager.getInstance().removeAllCookies(null)
                web.loadUrl(Config.LOGIN_URL)
            }
        }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
